import { makeStyles } from "@material-ui/styles";

const useStyleAuth = makeStyles((theme) => ({
  field: {
    "&&": {
      margin: "8px 0 !important ",
    },
  },
}));

export default useStyleAuth;
